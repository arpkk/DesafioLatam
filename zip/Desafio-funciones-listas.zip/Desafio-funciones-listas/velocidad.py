def promedio(velocidad):
    sum = 0
    for i in velocidad:
        sum += i
    return sum / len(velocidad)
