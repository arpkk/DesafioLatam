import sys
n=int(sys.argv[1])

parrafo= "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque malesuada felis ac purus placerat, sit amet molestie nisl ullamcorper. Aliquam lacinia neque egestas nisi blandit lobortis. Aenean ac gravida lorem. Aliquam blandit lectus ut eros semper, non auctor velit accumsan. Interdum et malesuada fames ac ante ipsum primis in faucibus. Nunc accumsan quam arcu, quis convallis sapien imperdiet sed. Donec faucibus lacus quam, vel pretium leo iaculis sed. Nullam luctus ex at massa placerat, sit amet sollicitudin quam venenatis. Proin nisi enim, viverra ut ipsum ac, facilisis scelerisque risus. Praesent bibendum sem in est egestas scelerisque. Vivamus molestie felis ipsum, eu convallis metus iaculis et."

for i in range(n):
    print(parrafo)
    print("")