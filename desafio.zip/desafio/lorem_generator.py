n=sys.argv[1]
