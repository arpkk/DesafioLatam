n = int(input("Ingrese la cantidad de filas\n"))
print("\n")

columna = ""
for i in range(1, n + 1):
    columna = columna + str(i)
    print(columna)